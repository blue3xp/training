package com.example.thefirstcompose

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun RowText() {
//    Text("android compose")
//    Text("android compose1")
//    Text("android compose2")

    Row {
        Text("android compose")
        Text("android compose1")
        Text("android compose2")
    }
}

@Composable
fun RowBox() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
    ) {
        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Yellow))
        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Green))
        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Red))
    }
}