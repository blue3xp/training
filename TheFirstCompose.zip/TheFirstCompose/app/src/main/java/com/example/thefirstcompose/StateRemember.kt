package com.example.thefirstcompose

import android.annotation.SuppressLint
import androidx.compose.material3.Button
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@SuppressLint("UnrememberedMutableState")
@Composable
fun WaterCounter(modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(16.dp)) {
        //当状态发生变化时，Compose 没有重新绘制屏幕（即“重组”可组合函数）。
//        var count = 0
        //使用 Compose 的 State 和 MutableState 类型让 Compose 能够观察到状态。
        // Changes to count are now tracked by Compose
//        val count: MutableState<Int> = mutableStateOf(0)
        //使用 remember 可组合内嵌函数。系统会在初始组合期间将由 remember 计算的值存储在组合中，并在重组期间一直保持存储的值。
        val count: MutableState<Int> = remember { mutableStateOf(0) }

//        Text("You've had $count glasses.")
        Text("You've had ${count.value} glasses.")
        Button(onClick = {
//                 count++
                   count.value++
        }, Modifier.padding(top = 8.dp)) {
            Text("Add one")
        }
    }
}

