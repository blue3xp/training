package com.example.thefirstcompose

import android.annotation.SuppressLint
import androidx.compose.material3.Button
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@SuppressLint("UnrememberedMutableState")
@Composable
fun WaterCounter(modifier: Modifier = Modifier) {
    Column(modifier = modifier.padding(16.dp)) {
        //当状态发生变化时，Compose 没有重新绘制屏幕（即“重组”可组合函数）。
//        var count = 0
        //使用 Compose 的 State 和 MutableState 类型让 Compose 能够观察到状态。
        // Changes to count are now tracked by Compose
//        val count: MutableState<Int> = mutableStateOf(0)
        //使用 remember 可组合内嵌函数。系统会在初始组合期间将由 remember 计算的值存储在组合中，并在重组期间一直保持存储的值。
        val count: MutableState<Int> = remember { mutableStateOf(0) }

//        Text("You've had $count glasses.")
        Text("You've had ${count.value} glasses.")
        Button(onClick = {
//                 count++
                   count.value++
        }, Modifier.padding(top = 8.dp)) {
            Text("Add one")
        }
    }
}

@Composable
fun ListScreen() {
    // 使用 mutableStateOf 创建一个可观察的状态对象
    val itemList = remember { mutableStateOf(mutableListOf("Item 1", "Item 2", "Item 3")) }
//    val itemList = remember { mutableStateOf(listOf("Item 1", "Item 2", "Item 3")) }

    /**
    // 在 Composable 函数中更新状态
//    LaunchedEffect(Unit) {
//        // 模拟从服务器获取数据的过程
//        delay(1000)
//        itemList.value = itemList.value.plus("Item4")
//    }
    **/

    // 在 Composable 函数中使用状态
    Column {
        itemList.value.forEach { item ->
            Text(item)
        }
        Button(onClick = {
             itemList.value.add("Item 4")
            //plus 是返回一个新的数组
//            itemList.value = itemList.value.plus("Item4")
        }, Modifier.padding(top = 8.dp)) {
            Text("Add one")
        }
    }

}

data class MyData(
    //设置常量的原因是防止修改
    val id: Int,
    val name: String
//    var name: String
)

// 在 Composable 函数中使用
@Composable
fun DataScreen() {
    // 创建一个可观察的状态
    val myDataList = remember { mutableStateListOf<MyData>() }

    Column {
        myDataList.forEach { data ->
            Text("ID: ${data.id}, Name: ${data.name}")
        }
        Button(onClick = {
            myDataList.add(MyData(1, "John"))
        }, Modifier.padding(top = 8.dp)) {
            Text("Add one")
        }
        Button(onClick = {
            myDataList.removeAt(0)
        }, Modifier.padding(top = 8.dp)) {
            Text("remove one")
        }
        Button(onClick = {
//            myDataList[0].name = "Alice"
            myDataList[0] = myDataList[0].copy(name = "Alice")
        }, Modifier.padding(top = 8.dp)) {
            Text("update one")
        }
    }
}

