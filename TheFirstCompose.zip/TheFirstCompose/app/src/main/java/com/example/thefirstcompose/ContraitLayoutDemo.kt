package com.example.thefirstcompose

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ChainStyle
import androidx.constraintlayout.compose.ConstraintLayout

@Composable
fun ConstraintDemo1() {
    ConstraintLayout(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
    ) {
        val (yellowBox, greenBox, redBox) = createRefs()

        //对齐父容器
        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Yellow)
            .constrainAs(redBox) {
                top.linkTo(parent.top)
                bottom.linkTo(parent.bottom)
                start.linkTo(parent.start)
                end.linkTo(parent.end)
            }
        )

        //对齐父容器，加入 margin 间距
        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Green)
            .constrainAs(greenBox) {
                top.linkTo(parent.top, 150.dp)
                bottom.linkTo(parent.bottom)
                start.linkTo(parent.start)
                end.linkTo(parent.end)
            })

        //对齐其他元件，并对齐margin
        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Red)
            .constrainAs(yellowBox) {
                top.linkTo(greenBox.bottom)
                start.linkTo(greenBox.end, 20.dp)
            })
    }

}

@Composable
fun ConstraintDemo2() {
    ConstraintLayout(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
    ) {
        val (yellowBox) = createRefs()

        val topGuideline = createGuidelineFromTop(0.1f)

        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Yellow)
            .constrainAs(yellowBox) {
                top.linkTo(topGuideline)
                start.linkTo(parent.start)
                end.linkTo(parent.end)

            })
    }

}

@Composable
fun ConstraintDemo3() {
    ConstraintLayout(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
    ) {
        val (yellowBox, greenBox, redBox) = createRefs()

        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Yellow)
            .constrainAs(redBox) {})

        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Green)
            .constrainAs(greenBox) {})

        Box(modifier = Modifier
            .size(50.dp)
            .background(Color.Red)
            .constrainAs(yellowBox) {})

        //水平
//        createHorizontalChain(redBox, greenBox, yellowBox, chainStyle = ChainStyle.Spread)
//        createHorizontalChain(redBox, greenBox, yellowBox, chainStyle = ChainStyle.SpreadInside)
//        createHorizontalChain(redBox, greenBox, yellowBox, chainStyle = ChainStyle.Packed)

//垂直
        createVerticalChain(redBox, greenBox, yellowBox,chainStyle = ChainStyle.Spread)
//        createVerticalChain(redBox, greenBox, yellowBox, chainStyle = ChainStyle.SpreadInside)
//        createVerticalChain(redBox, greenBox, yellowBox, chainStyle = ChainStyle.Packed)
    }
}