package com.example.thefirstcompose

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun TextDemo() {
    Column {
        Text("android compose")
        //设置颜色
        Text("android compose",
            color = Color.Red)
        // RGB 自定义颜色
        Text("android compose",
            color = Color(0, 100, 100))
        // RGB 自定义颜色
        Text("android compose",
            color = Color(0, 100, 100))
        // 16位進制，Hex 自定義顏色
        //https://www.color-hex.com
        Text("android compose",
            color = Color(0xFF9856C8))
        //https://www.color-hex.com
        Text("android compose",
            color = Color(0xFF9856C8))
        //改变字体大小
        Text(
            "11111111",
            fontSize = 20.sp
        )

        Text(
            "11111111",
            fontSize = DpToSp(dp = 20.dp)
        )
        //字体样式
       //粗体
        Text(
            "android compose",
            fontWeight = FontWeight.Bold
        )

        //斜体
        Text(
            "android compose",
            fontStyle = FontStyle.Italic
        )
        //删除线
        Text(
            text = "android compose",
            textDecoration = TextDecoration.Underline
        )

        Text(
            text = "android compose",
            textDecoration = TextDecoration.LineThrough
        )

        //内部间距
        Text(
            "android compose",
            modifier = Modifier
                .background(Color.Red)
                .padding(all = 20.dp)
        )
        //多语言
        //英文：res/values

        Text(
            text = stringResource(R.string.weather)
        )





    }



}

@Composable
fun DpToSp(dp: Dp) = with(LocalDensity.current) { dp.toSp() }
