package com.example.thefirstcompose

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import kotlin.math.pow

@Composable
fun TextFieldDemo1() {
    //输入文字，显示在标签
    Column{
        var textVal by remember { mutableStateOf("") }

        TextField(
            value = textVal,
            onValueChange = { textVal = it}
        )

        Text(textVal)
    }

}

@Composable
fun TextFieldDemo2() {
    //键盘
    var textVal by remember { mutableStateOf("") }

    TextField(
        value = textVal,
        onValueChange = { textVal = it },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}


@Composable
fun TextFieldDemo3() {
    //按钮按下获取文字
    Column {
        var textVal by remember { mutableStateOf("") }
        var inputData by remember { mutableStateOf("") }

        TextField(
            value = textVal,
            onValueChange = { textVal = it }
        )

        Button(onClick = {
            inputData = textVal
        }) {
            Text(text = "获取文字框文字")
        }

        Text(inputData)
    }
}

@Composable
fun TextFieldDemo4() {
    var heightVal by rememberSaveable { mutableStateOf("") }
    var weightVal by rememberSaveable { mutableStateOf("") }
    var resultVal by rememberSaveable { mutableStateOf("") }


    ConstraintLayout(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth()
    ) {

        val (textTitle,
            inputHeight,
            inputWeight,
            textResult,
            btnCalc,
            btnClean) = createRefs()

        val topGuideline = createGuidelineFromTop(0.1f)

        Text("BMI计算器",
            fontSize = 50.sp,
            modifier = Modifier.constrainAs(textTitle) {
                top.linkTo(topGuideline)
                start.linkTo(parent.start)
                end.linkTo(parent.end)
            })

        TextField(
            value = heightVal,
            onValueChange = { heightVal = it },
            label = { Text("身高(cm)") },
            singleLine = true,
            modifier = Modifier
                .constrainAs(inputHeight) {
                    top.linkTo(textTitle.bottom, 20.dp)
                    start.linkTo(parent.start)
                    end.linkTo(parent.end)
                }
        )

        TextField(
            value = weightVal,
            onValueChange = { weightVal = it },
            label = { Text("体重(kg)") },
            singleLine = true,
            modifier = Modifier.constrainAs(inputWeight) {
                top.linkTo(inputHeight.bottom, 20.dp)
                start.linkTo(parent.start)
                end.linkTo(parent.end)
            }
        )

        if (resultVal.isNotBlank()) {
            Text(resultVal,
                fontSize = 20.sp,
                modifier = Modifier.constrainAs(textResult) {
                    top.linkTo(inputWeight.bottom, 20.dp)
                    start.linkTo(parent.start)
                    end.linkTo(parent.end)
                })
        }

        Button(onClick = {
            resultVal = calcBMI(height = heightVal, weight = weightVal)
        },
            modifier = Modifier
                .constrainAs(btnCalc) {
                    bottom.linkTo(parent.bottom, 10.dp)
                    start.linkTo(parent.start)
                    end.linkTo(btnClean.start)
                }) {
            Text("计算", fontSize = 50.sp)
        }

        Button(onClick = {
            heightVal = ""
            weightVal = ""
            resultVal = ""
        },
            modifier = Modifier
                .constrainAs(btnClean) {
                    bottom.linkTo(parent.bottom, 10.dp)
                    start.linkTo(btnCalc.end)
                    end.linkTo(parent.end)
                }) {
            Text("清除", fontSize = 50.sp)
        }
    }
}

fun calcBMI(height: String, weight: String): String {

    val bmi = weight.toDouble() / (height.toDouble() / 100).pow(2.0)
    val bmiData = String.format("%.1f", bmi)

    var result = ""
    if (bmi < 18.5) {
        result = "太瘦了～"
    } else if (bmi > 18.5 && bmi < 24.9) {
        result = "标准，很棒～"
    } else if (bmi > 24.9 && bmi < 30) {
        result = "过胖!!!"
    } else {
        result = "肥胖!"
    }
    return "你的 BMI : $bmiData \n $result";
}



