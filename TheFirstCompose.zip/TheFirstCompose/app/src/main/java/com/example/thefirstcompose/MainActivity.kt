package com.example.thefirstcompose

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.example.thefirstcompose.ui.theme.TheFirstComposeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
//            TheFirstComposeTheme {
//                // A surface container using the 'background' color from the theme
//                Surface(
//                    modifier = Modifier.fillMaxSize(),
//                    color = MaterialTheme.colorScheme.background
//                ) {
//                    Greeting("Android")
//                }
//            }
//            ColumnBox()
//            ColumnText()
//            RowText()
//            RowBox()
//            BoxDemo()
//            TextDemo()
//            ButtonDemo()
//            CounterDemo()
//            ConstraintDemo1()
//            TextFieldDemo1()
//            TextFieldDemo2()
//            TextFieldDemo3()
//            TextFieldDemo4()
//            ImageDemo1()
//            ImageDemo2()
//            SlotDemo(
//                topContent = { View1() },
//                midContent = { View2() },
//                bottomContent = { View3() }
//            )
//            MutableStateDemo()
//            RememberSaveDemo()
//            HelloScreen()
//            GestureOfClick()
//            ScrollBoxes()
//            AutomaticNestedScroll()
//            DraggableTextLowLevel()
//            DragGestureDemo()
//            TapGestureDemo()
//            NavGraph()
//            Surface(color = Color.White) {
//                ScaffoldExample()
//            }
//            WaterCounter()
//            ListScreen()
//            DataScreen()
//            ViewModelScreen()
//            PersonList()
//            HomeDetail()
            LifecycleDemo()
//            SideEffectProduceDemo("ss")
//            LoginScreen()
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    TheFirstComposeTheme {
        Greeting("Android")
    }
}