package com.example.thefirstcompose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.google.gson.Gson

data class Student(val name: String, val score: String)

sealed class Routes(val route: String) {
    object APage : Routes("a_page")
    object BPage : Routes("b_page")
    object CPage : Routes("c_page")
}

@Composable
fun NavGraph(startDestination: String = Routes.APage.route) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable(
            Routes.APage.route
        ) {
            APage(navController)
        }

//        composable(
//            Routes.BPage.route
//        ) {
//            BPage(navController)
//        }

//        composable(
//            Routes.BPage.route + "/{student_name}/{student_score}",
//            arguments = listOf(
//                navArgument("student_name") { type = NavType.StringType },
//                navArgument("student_score") { type = NavType.IntType },
//            ),
//        ) {
//            BPage(
//                navController,
//                it.arguments?.getString("student_name", "") ?: "",
//                it.arguments?.getInt("student_score") ?: 0,
//            )
//        }

       //可选参数传递
//        composable(
//            Routes.BPage.route + "?student_name={student_name}&student_score={student_score}",
//            arguments = listOf(
//                navArgument("student_name") {
//                    type = NavType.StringType
//                    defaultValue = "资料错误"
//                },navArgument("student_score") {
//                    type = NavType.IntType
//                    defaultValue = -1
//                },
//            ),
//        ) {
//            BPage(
//                navController,
//                it.arguments?.getString("student_name", "资料错误") ?: "",
//                it.arguments?.getInt("student_score") ?: -1,
//            )
//        }

       //传递对象
        composable(
            Routes.BPage.route + "/{student}",
            arguments = listOf(
                navArgument("student") { type = NavType.StringType }
            ),
        ) {
            val defaultStudent = it.arguments?.getString("student", "") ?: ""
            val student = Gson().fromJson(defaultStudent, Student::class.java)
            BPage(
                navController,
                student
            )
        }




        composable(
            Routes.CPage.route
        ) {
            CPage(navController)
        }
    }
}

//@Composable
//fun APage(navController: NavHostController) {
//    BasePage("A 页面内容", "前往") {
////        navController.navigate(Routes.BPage.route)
////        navController.navigate(Routes.BPage.route + "/jack/100")
//        navController.navigate(Routes.BPage.route + "?student_name=Jack&student_score=100")
//
//
//    }
//}

@Composable
fun APage(navController: NavHostController) {
    val student = Student("Jack", "100")
    val gson = Gson().toJson(student)

    BasePage("A 页面内容", "前往") {
        navController.navigate(Routes.BPage.route + "/$gson")
    }
}



//@Composable
//fun BPage(navController: NavHostController) {
//    BasePage("B 页面內容", "前往") {
//        navController.navigate(Routes.CPage.route)
//    }
//}

//@Composable
//fun BPage(navController: NavHostController, student_name: String, student_score: Int) {
//    BasePage("Ｂ页面内容 \n 学生姓名：$student_name \n 成绩：$student_score", "返回") {
////        navController.navigate(Routes.APage.route)
//        navController.navigateUp()
//    }
//}

@Composable
fun BPage(navController: NavHostController, student: Student) {

    BasePage("Ｂ页面內容 \n 学生姓名：${student.name}  \n 成绩：${student.score}", "返回") {
        navController.navigateUp()
    }
}





@Composable
fun CPage(navController: NavHostController) {
    BasePage("C 页面内容", "返回") {
//        navController.navigateUp()
        /**
         * Ａ->Ｂ->Ｃ->Ａ->Ａ
         * popUpTo 移除中间页，返回Ａ，可以 pop up 移除Ｂ、Ｃ
         *
         * Ａ->Ｂ->Ｃ->A
         * popUpToInclusive = true 可以减少兩个 Ａ 页产生。
         *
         *
         */
        navController.navigate(Routes.APage.route){
            popUpTo(Routes.APage.route) {
                inclusive = true
                //会重新产生新的A
//                inclusive = false
            }
        }

    }
}

@Composable
fun BasePage(pageContent: String, btnContent: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            pageContent,
            fontSize = 30.sp,
            modifier = Modifier.padding(bottom = 100.dp)
        )
        Button(
            modifier = Modifier
                .width(150.dp)
                .height(100.dp),
            onClick = {
                onClick()
            }
        ) {
            Text(btnContent)
        }
    }
}


