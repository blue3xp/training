package com.example.thefirstcompose

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout

@Composable
fun ButtonDemo() {
    Column {
        Button(
            onClick = { Log.d("Demo", "onClick...") },
        ) {
            Text(text = "android compose")
        }
        //按钮颜色
        Button(
            onClick = {},
            colors = ButtonDefaults.textButtonColors(
                containerColor = Color.Green,
                contentColor = Color.Black
            )
        ) {
            Text("android compose", color = Color.Blue)
        }
        //按钮间距
        Button(
            onClick = {},
            contentPadding = PaddingValues(
                start = 20.dp,
                top = 10.dp,
                end = 20.dp,
                bottom = 10.dp
            ),
            modifier = Modifier.padding(50.dp)
        ) {
            Text("android compose", fontSize = 30.sp)
        }

        //图案按钮
        //https://fonts.google.com/icons

        Button(
            onClick = { /* ... */ },
            contentPadding = PaddingValues(
                start = 20.dp,
                top = 12.dp,
                end = 20.dp,
                bottom = 12.dp
            )
        ) {
            Icon(
                Icons.Filled.Favorite,
                contentDescription = "Favorite",
                modifier = Modifier.size(ButtonDefaults.IconSize)
            )
            Spacer(Modifier.size(ButtonDefaults.IconSpacing))
            Text("Like")
        }

    }


}

@Composable
fun CounterDemo() {
    //    var counter = 0

    var counter by remember {
        mutableStateOf(0)
    }


    ConstraintLayout(
        modifier = Modifier
            .fillMaxSize()
    ) {

        val (textCounter,
            btnPlus,
            btnMinus) = createRefs()

        val topGuideline = createGuidelineFromTop(0.2f)
        val bottomGuideline = createGuidelineFromBottom(0.2f)

        Text("$counter",
            fontSize = 50.sp,
            modifier = Modifier.constrainAs(textCounter) {
                top.linkTo(topGuideline)
                start.linkTo(parent.start)
                end.linkTo(parent.end)
            })



        Button(onClick = {
            counter++
        },
            modifier = Modifier
                .constrainAs(btnPlus) {
                    bottom.linkTo(bottomGuideline)
                    start.linkTo(parent.start)
                    end.linkTo(btnMinus.start)
                }) {
            Text("+1", fontSize = 50.sp)
        }

        Button(onClick = {
            counter--
        },
            modifier = Modifier
                .constrainAs(btnMinus) {
                    bottom.linkTo(bottomGuideline)
                    start.linkTo(btnPlus.end)
                    end.linkTo(parent.end)
                }) {
            Text("-1", fontSize = 50.sp)
        }
    }
}