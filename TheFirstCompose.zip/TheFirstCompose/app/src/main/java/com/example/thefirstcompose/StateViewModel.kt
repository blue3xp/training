package com.example.thefirstcompose

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel

// ViewModel.kt
class MainViewModel : ViewModel() {
    private val _uiState = MutableLiveData<UiState>()
    val uiState: LiveData<UiState> = _uiState

    fun loadData() {
        // 模拟从服务器获取数据
        val data = listOf("Item 1", "Item 2", "Item 3")
        _uiState.value = UiState.Success(data)
    }

    fun handleError(error: Throwable) {
        _uiState.value = UiState.Error(error)
    }


    fun refreshData() {
        _uiState.value = UiState.Loading
        viewModelScope.launch {
            delay(1000)
            try {
                val data = fetchDataFromNetwork()
                _uiState.value = UiState.Success(data)

            } catch (e: Exception) {
                _uiState.value = UiState.Error(e)
            }
        }

    }

    private fun fetchDataFromNetwork():List<String>{
        return listOf("Item 1", "Item 2", "Item 3","Item 4")
    }

}

// UiState.kt
sealed class UiState {
    object Loading : UiState()
    data class Success(val data: List<String>) : UiState()
    data class Error(val error: Throwable) : UiState()
}

class HomeViewModel : ViewModel() {
    // Create a MutableLiveData instance that keeps a string
    val userName = MutableLiveData<String>()
}

// MainScreen.kt
@Composable
fun ViewModelScreen(viewModel: MainViewModel = viewModel()) {
    val uiState by viewModel.uiState.observeAsState(UiState.Loading)

    Column {
        when (uiState) {
            is UiState.Success -> {
                val data = (uiState as UiState.Success).data
                DataList(data)
            }
            is UiState.Error -> {
                val error = (uiState as UiState.Error).error
                ErrorMessage(error.message ?: "Unknown error")
            }
            else -> {
                // 显示加载中的状态
                LoadingIndicator()
            }
        }
        Button(onClick = {
            viewModel.refreshData()
        }, Modifier.padding(top = 8.dp)) {
            Text("refresh")
        }
    }


    // 在需要时调用 loadData()
    LaunchedEffect(Unit) {
        delay(1000)
        viewModel.loadData()
    }
}

// Composable 函数
@Composable
fun DataList(data: List<String>) {
    LazyColumn {
        items(data) { item ->
            Text(item)
        }
    }
}

@Composable
fun ErrorMessage(message: String) {
    Text("Error: $message")
}

@Composable
fun LoadingIndicator() {
    // 显示加载中的指示器
    CircularProgressIndicator()
}