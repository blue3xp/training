package com.example.thefirstcompose

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun HomeDetail(
    viewModel: HomeViewModel = HomeViewModel()
) {
    Log.e("---345--->", viewModel.state.name);
    Log.e("---345--->", viewModel.toString());
    Scaffold() {
        Column() {
            Spacer(modifier = Modifier.padding(top = 50.dp))

            Button(onClick = {
                viewModel.state = MyUserState("张三", 50)
            }) {
                Text(text = "按钮")
            }
            Spacer(modifier = Modifier.padding(top = 100.dp))
            Text(text = "姓名 ${viewModel.state.name}")
            Text(text = "姓名 ${viewModel.state.age}")
        }
    }
}

class HomeViewModel : ViewModel() {
    var state by mutableStateOf(MyUserState())
}

class MyUserState(
    var name: String = "345",
    var age: Int = 20
) {
    var sex: String = "男"

    fun getUserId(): Int {
        return 0
    }
}
