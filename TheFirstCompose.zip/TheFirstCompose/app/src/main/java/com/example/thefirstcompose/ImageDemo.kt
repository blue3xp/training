package com.example.thefirstcompose

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage


@Composable
fun ImageDemo1() {
    // 显示本机图片
//val image: Painter = painterResource(id = R.drawable.hktlogo)

    Image(
        painter = painterResource(R.drawable.googlelogo),
        contentDescription = ""
    )

}

@Composable
fun ImageDemo2() {
    //https://coil-kt.github.io/coil/
    AsyncImage(
        model = "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_92x30dp.png",
        contentDescription = null
    )
}

@Composable
fun ImageDemo3() {
    //图片大小，延展
    Image(
        painter = painterResource(R.drawable.work),
        contentDescription = "",
        modifier = Modifier
            .size(100.dp, 100.dp)
            .background(Color.Red)
            .clip(CircleShape),
        contentScale = ContentScale.FillHeight
    )

}