package com.example.thefirstcompose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

@Composable
fun SlotDemo(
    topContent: @Composable () -> Unit,
    midContent: @Composable () -> Unit,
    bottomContent: @Composable () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        topContent()
        midContent()
        bottomContent()
    }
}

@Composable
fun View1() {
    Text("上层內容")

}

@Composable
fun View2() {
    Text("中层內容")
}

@Composable
fun View3() {
    Text("底层內容")
}
