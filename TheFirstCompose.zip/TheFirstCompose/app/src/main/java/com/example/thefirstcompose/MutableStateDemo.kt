package com.example.thefirstcompose

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MutableStateDemo(){
    var value1 = remember { mutableStateOf("compose") }
    var value2 by remember { mutableStateOf("compose") }
    var (value3, setValue) = remember { mutableStateOf("compose") }

    Column(Modifier.padding(20.dp)) {
        Text("value1 Demo", fontSize = 20.sp, textDecoration = TextDecoration.Underline)
        Text("value1: $value1")
        Text("value1: ${value1.value}")
        value1.value = "value1"
        Text("value1: ${value1.value}")

        Spacer(modifier = Modifier.height(50.dp))

        Text("value2 Demo", fontSize = 20.sp, textDecoration = TextDecoration.Underline)
        Text("value2: $value2")
        value2 = "value2"
        Text("value2: $value2")

        Spacer(modifier = Modifier.height(50.dp))

        Text("value3 Demo", fontSize = 20.sp, textDecoration = TextDecoration.Underline)
        Text("value3: $value3")
        value3 = "value3"
        Text("value3: $value3")
    }

}

@Composable
fun RememberSaveDemo(){
    //activity 重建 rememberSaveable 会保留上一次状态。
    var counter1 by remember { mutableStateOf(0) }
    var counter2 by rememberSaveable { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "counter1: $counter1",
            modifier = Modifier.padding(10.dp),
            fontSize = 30.sp
        )
        Text(
            "counter2: $counter2",
            modifier = Modifier.padding(10.dp),
            fontSize = 30.sp
        )
        Button(
            modifier = Modifier
                .width(150.dp)
                .height(100.dp),
            onClick = {
                counter1++
                counter2++
            }
        ) {
            Text("＋１")
        }
    }

}

//提升前
@Composable
fun HelloContent1() {
    Column(modifier = Modifier.padding(16.dp)) {
        var name by remember { mutableStateOf("") }
        if (name.isNotEmpty()) {
            Text(
                text = "Hello, $name!",
                modifier = Modifier.padding(bottom = 8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name") }
        )
    }
}

//状态提升
@Composable
fun HelloScreen() {
    var name by rememberSaveable { mutableStateOf("") }

    HelloContent2(name = name, onNameChange = { name = it })
}

@Composable
fun HelloContent2(name: String, onNameChange: (String) -> Unit) {
    Column(modifier = Modifier.padding(16.dp)) {
        if (name.isNotEmpty()) {
            Text(
                text = "Hello, $name",
                modifier = Modifier.padding(bottom = 8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
        OutlinedTextField(
            value = name,
            onValueChange = onNameChange,
            label = { Text("Name") }
        )
    }
}

