package com.example.thefirstcompose

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch


@Composable
fun LifecycleDemo() {
    val count = remember { mutableStateOf(0) }

    val counterFlow = snapshotFlow { count.value }

    LaunchedEffect(Unit) {
        counterFlow.collect { count ->
            Log.d("Compose", "Counter value: $count")
        }
    }

    val isEven by remember {
        derivedStateOf {
            count.value > 4
        }
    }



    // Creates a CoroutineScope bound to the LifecycleDemo's lifecycle
    val scope = rememberCoroutineScope()

    Column {
        Button(onClick = {
            count.value++
        }) {
            Text("Click me")
        }

        Button(onClick = {
            scope.launch {
                delay(1000)
                count.value++
            }

        }) {
            Text("Asynchronous click me ")
        }

        LaunchedEffect(Unit){
            Log.d("Compose", "onactive with value: " + count.value)
        }
        DisposableEffect(Unit) {
            onDispose {
                Log.d("Compose", "onDispose because value=" + count.value)
            }
        }
        DisposableEffect(count.value) {
            // 添加事件监听器
            val listener: (String) -> Unit = { msg ->
                println("Received message: $msg")
            }
            SomeObject.addListener(listener)

            // 返回一个 Disposable 对象,用于清理事件监听器
            onDispose {
                SomeObject.removeListener(listener)
            }
        }
        SideEffect {
            Log.d("Compose", "onChange with value: " + count.value)
        }
        Text(text = "You have clicked the button: " + count.value.toString())
        Text("Count is greater than 4: $isEven")
        Timer(count = count.value)
    }
}

@Composable
fun Timer(
    count: Int
) {
    val timerDuration = 10000L
    Log.d("Compose", "Composing timer with colour : $count")
    val countUpdated by rememberUpdatedState(newValue = count)
    LaunchedEffect(key1 = Unit, block = {
        startTimer(timerDuration) {
            Log.d("Compose", "Timer ended")
            Log.d("Compose", "count is $count")
            Log.d("Compose", "updated count is $countUpdated")
        }
    })
}

suspend fun startTimer(time: Long, onTimerEnd: () -> Unit) {
    delay(timeMillis = time)
    onTimerEnd()
}

object SomeObject {
    private val listeners = mutableSetOf<(String) -> Unit>()

    fun addListener(listener: (String) -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: (String) -> Unit) {
        listeners.remove(listener)
    }

    fun notifyListeners(message: String) {
        listeners.forEach { it(message) }
    }
}

@Composable
fun SideEffectProduceDemo(userId: String) {
    val userData by produceState<UserData?>(null, userId) {
        // 在这里执行异步操作,如网络请求,并更新状态
        val data = fetchUserData(userId)
        value = data
    }

    // 渲染 UI
    when (userData) {
        null -> Text("Loading...")
        else -> Text("User name: ${userData!!.name}")
    }
}

data class UserData(
    val name: String,
    val email: String,
    // 其他用户数据
)

// 假设这是一个网络请求函数
suspend fun fetchUserData(userId: String): UserData {
    // 模拟网络请求
    delay(2000)
    return UserData("John Doe", "john.doe@example.com")
}

@Composable
fun PersonList() {
    val persons = listOf(
        Person("1","test1","test1@122.com"),
        Person("2","test2","test2@122.com")
    )
    LazyColumn {
        items(persons, key = { it.id }) { person ->
            PersonItem(person)
        }
    }
}

@Composable
fun PersonItem(person: Person) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(person.name, style = MaterialTheme.typography.titleLarge)
            Text(person.email, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

data class Person(
    val id: String,
    val name: String,
    val email: String,
)

