package com.example.thefirstcompose

import android.util.Log
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp


@Composable
fun LifecycleDemo() {
    val count = remember { mutableStateOf(0) }

    Column {
        Button(onClick = {
            count.value++
        }) {
            Text("Click me")
        }

        LaunchedEffect(Unit){
            Log.d("Compose", "onactive with value: " + count.value)
        }
        DisposableEffect(Unit) {
            onDispose {
                Log.d("Compose", "onDispose because value=" + count.value)
            }
        }
        SideEffect {
            Log.d("Compose", "onChange with value: " + count.value)
        }
        Text(text = "You have clicked the button: " + count.value.toString())
    }
}

