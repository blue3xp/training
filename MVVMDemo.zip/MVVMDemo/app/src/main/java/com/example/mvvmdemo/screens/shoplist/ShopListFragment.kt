package com.example.mvvmdemo.screens.shoplist

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mvvmdemo.MainViewModel
import com.example.mvvmdemo.R
import com.example.mvvmdemo.adapters.ShopListAdapter
import com.example.mvvmdemo.databinding.FragmentShopListBinding
import com.example.mvvmdemo.interfaces.CommonFunctions
import com.example.mvvmdemo.interfaces.OnFragmentInteractionListener
import com.example.mvvmdemo.interfaces.OnObjectListInteractionListener
import com.example.mvvmdemo.models.shop.ShopItem
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ShopListFragment  : Fragment(),
    CommonFunctions,
    OnObjectListInteractionListener<ShopItem> {

    private var listener: OnFragmentInteractionListener? = null

    private lateinit var binding: FragmentShopListBinding

    private val viewModel: ShopListViewModel by viewModels()
    private val parentViewModel: MainViewModel by viewModels(ownerProducer = {
        requireActivity()
    })

    private lateinit var adapter: ShopListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initObservers()

        adapter = ShopListAdapter(this)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentShopListBinding.inflate(inflater, container, false)
        binding.lifecycleOwner = this.viewLifecycleOwner
        binding.viewModel = viewModel
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        listener?.setAppTitle(getString(R.string.title_shop_list))

        viewModel.getUsers()

        initViews()

        initListeners()
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()

        viewModel.clearUserObservables()
    }

    override fun initViews() {
        // List
        val layoutManager = LinearLayoutManager(activity)
        binding.recyclerView.layoutManager = layoutManager

        val dividerItemDecoration = DividerItemDecoration(
            binding.recyclerView.context,
            layoutManager.orientation
        )
        binding.recyclerView.addItemDecoration(dividerItemDecoration)

        binding.recyclerView.adapter = adapter
    }

    override fun initListeners() {
    }

    override fun initObservers() {
//        viewModel.eventShowLoading
//            .observe(this) {
//                it?.apply {
//                    if (it == true) {
//                        listener?.showLoading()
//                    } else {
//                        listener?.hideLoading()
//                    }
//                }
//            }
        viewModel.eventShowLoading.observe(this) {
            it?.run {
                if (this) {
                    parentViewModel.showLoading()
                } else {
                    parentViewModel.hideLoading()
                }
            }
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)

        if (context is OnFragmentInteractionListener) {
            listener = context
        } else {
            throw RuntimeException("$context must implement OnFragmentInteractionListener")
        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }



    override fun onClick(position: Int, dataObject: ShopItem) {
        TODO("Not yet implemented")
    }

    override fun onLongClick(position: Int, dataObject: ShopItem) {
        TODO("Not yet implemented")
    }

    override fun showEmptyView() {
        binding.emptyView.emptyLayout.visibility = View.VISIBLE
    }

    override fun hideEmptyView() {
        binding.emptyView.emptyLayout.visibility = View.GONE
    }

}