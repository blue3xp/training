

package com.example.mvvmdemo.interfaces

import com.example.mvvmdemo.MainViewModel


interface MainActivityExtraOnFragmentInteractionListener {
    fun getActivityViewModel(): MainViewModel
}
