package com.example.mvvmdemo

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor() : ViewModel(){

    // ----------------------------------------------------------------

    private val _isLoadingVisible: MutableLiveData<Boolean> by lazy {
        MutableLiveData<Boolean>()
    }
    val isLoadingVisible: LiveData<Boolean>
        get() = _isLoadingVisible

    // ----------------------------------------------------------------

    fun showLoading() {
        _isLoadingVisible.postValue(true)
    }

    fun hideLoading() {
        _isLoadingVisible.postValue(false)
    }

}