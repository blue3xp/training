

package com.example.mvvmdemo.utils

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager

/**
 * Hide soft keyboard
 */
fun Activity.hideKeyboard() {
    val view = this.currentFocus
    view?.let { v ->
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(v.windowToken, 0)
    }
}

/**
 * Hide soft keyboard
 */
fun View.hideKeyboard() {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(windowToken, 0)
}

/**
 * Show soft keyboard
 */
fun View.showKeyboard() {
    this.requestFocus()
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.showSoftInput(this, InputMethodManager.SHOW_IMPLICIT)
}


/**
 * Open permission setting.
 */
fun Activity.openPermissionSetting(message: String) {
    this.longToast(message)

    val intent = Intent()
    intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
    val uri = Uri.fromParts("package", this.packageName, null)
    intent.data = uri
    this.startActivity(intent)
}

fun Activity.openUrl(url: String) {
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    } catch (e: Exception) {
        e.printStackTrace()

        longToast("Cannot open the link!")
    }
}

fun Context.sendEmail(
    fromEmail: String,
    subject: String,
    body: String
) {
    try {
        val emailIntent = Intent(Intent.ACTION_VIEW)
        val data =
            Uri.parse("mailto:$fromEmail?subject=$subject&body=$body")
        emailIntent.data = data
        this.startActivity(emailIntent)
    } catch (e: java.lang.Exception) {
        e.printStackTrace()

        longToast("No e-mail client found!")
    }
}
