package com.example.mvvmdemo.usecase

import com.example.mvvmdemo.models.shop.ShopItem
import kotlinx.coroutines.delay
import javax.inject.Inject
import kotlin.random.Random

class ShopListUseCase @Inject constructor(

){

    private val shopItem1 = ShopItem("【热卖爆款】拼接鞋面厚底小白鞋女拼色潮流低帮板鞋百搭休闲鞋","https://h2.appsimg.com/a.appsimg.com/upload/merchandise/pdcvis/2023/02/11/26/2ebfe884-8ebb-4eab-aba7-4e63a968120b_436x436_90.jpg","¥68")
    private val shopItem2 = ShopItem("【超值捡漏】男鞋厚底老爹鞋百搭春夏爆款网面透气跑步休闲运动鞋","https://h2.appsimg.com/a.appsimg.com/upload/merchandise/pdcvis/651730/2022/1230/169/9b1d4ec5-bdc6-4a6c-b7d2-8663b46d7906_436x436_90.jpg","¥60")
    private val shopItem3 = ShopItem("【爆款】春季透气网面百搭小白鞋板鞋男休闲运动鞋男鞋","https://h2.appsimg.com/a.appsimg.com/upload/merchandise/pdcvis/2023/05/26/64/56949f98-6c66-47de-9244-628d6ab21b0b_436x436_90.jpg","¥109")


    suspend fun getShopData(): List<ShopItem> {
        delay(1000) // 模拟耗时操作，暂停执行 1 秒钟
        val mockList = mutableListOf<ShopItem>();
        for (i in 1..30) {
            val typeList = listOf(shopItem1,shopItem2,shopItem3);
            val randomNumber = Random.nextInt(3)
            val randomID = Random.nextInt(30);
            val shopTmp = typeList[randomNumber]
            shopTmp.id = randomID;
            mockList.add(shopTmp)
        }
        return mockList
    }
}

