package com.example.mvvmdemo

import android.animation.Animator
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.databinding.DataBindingUtil
import androidx.navigation.NavController
import androidx.navigation.NavDirections
import androidx.navigation.fragment.NavHostFragment
import com.example.mvvmdemo.databinding.ActivityMainBinding
import com.example.mvvmdemo.interfaces.CommonFunctions
import com.example.mvvmdemo.interfaces.MainActivityExtraOnFragmentInteractionListener
import com.example.mvvmdemo.interfaces.OnFragmentInteractionListener
import com.example.mvvmdemo.utils.Utils.ignoreCrash
import com.example.mvvmdemo.utils.hideKeyboard
import dagger.hilt.android.AndroidEntryPoint
import timber.log.Timber

//<!--        android:theme="@style/Theme.MVVMDemo"-->
@AndroidEntryPoint
class MainActivity : AppCompatActivity(), CommonFunctions,
    MainActivityExtraOnFragmentInteractionListener, OnFragmentInteractionListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController
    private val viewModel: MainViewModel by viewModels()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val navHostFragment =
            supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController
        initObservers()
        initViews()
        initListeners()
        Timber.d("  - Activity :${this.hashCode()}")
        Timber.d("  - ViewModel:${viewModel.hashCode()}")

    }

    override fun initViews() {
        /* no-op */
    }

    override fun initListeners() {
        /* no-op */
    }

    override fun initObservers() {
        viewModel.isLoadingVisible.observe(this) { isLoadingVisible ->
            if (isLoadingVisible){
                showLoading()
            }
            else{
                hideLoading()
            }
        }
    }

    override fun getActivityViewModel(): MainViewModel {
        return viewModel
    }

    override fun setAppTitle(title: String) {
        setTitle(title)
    }

    override fun navigate(destinationResId: Int) {
        hideKeyboard()

        if (navController.currentDestination == null) {
            navController.navigate(destinationResId)
        } else {
            navController.currentDestination?.let {
                if (it.id != destinationResId) {
                    navController.navigate(destinationResId)
                }
            }
        }
    }

    override fun navigate(destinationResId: Int, data: Bundle) {
        hideKeyboard()

        if (navController.currentDestination == null) {
            navController.navigate(destinationResId, data)
        } else {
            navController.currentDestination?.let {
                if (it.id != destinationResId) {
                    navController.navigate(destinationResId, data)
                }
            }
        }
    }

    override fun navigate(navDirections: NavDirections) {
        hideKeyboard()

        navController.navigate(navDirections)
    }

    override fun goBack() {
        hideKeyboard()

        onBackPressedDispatcher.onBackPressed()
    }

    override fun showSnackbar(message: String) {

    }

    override fun showSnackbar(message: String, buttonText: String, action: (View) -> Unit) {

    }

    override fun showLoading() {
        ignoreCrash {
            binding.loadingView.globalLoadingLayout.animate()
                .alpha(1f)
                .setDuration(200)
                .setListener(object : Animator.AnimatorListener {
                    override fun onAnimationStart(animation: Animator) {
                        binding.loadingView.globalLoadingLayout.alpha = 0f
                        binding.loadingView.globalLoadingLayout.visibility = View.VISIBLE
                    }

                    override fun onAnimationEnd(animation: Animator) {}
                    override fun onAnimationCancel(animation: Animator) {}
                    override fun onAnimationRepeat(animation: Animator) {}
                })
                .start()
        }
    }

    override fun hideLoading() {
        ignoreCrash {
            binding.loadingView.globalLoadingLayout.animate()
                .alpha(0f)
                .setDuration(200)
                .setListener(object : Animator.AnimatorListener {
                    override fun onAnimationEnd(animation: Animator) {
                        binding.loadingView.globalLoadingLayout.visibility = View.GONE
                    }

                    override fun onAnimationRepeat(animation: Animator) {}
                    override fun onAnimationCancel(animation: Animator) {}
                    override fun onAnimationStart(animation: Animator) {}
                })
                .start()
        }
    }
}

