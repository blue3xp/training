package com.example.mvvmdemo.screens.shoplist

import androidx.fragment.app.Fragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mvvmdemo.interfaces.CommonFunctions
import com.example.mvvmdemo.models.shop.ShopItem
import com.example.mvvmdemo.usecase.ShopListUseCase
import dagger.hilt.android.AndroidEntryPoint
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ShopListViewModel @Inject constructor(
    private val shopListUseCase: ShopListUseCase
) : ViewModel() {

    // ----------------------------------------------------------------
    private val _shopItems: MutableLiveData<List<ShopItem>> by lazy {
        MutableLiveData<List<ShopItem>>()
    }

    val shopItems: LiveData<List<ShopItem>>
        get() = _shopItems

    // ----------------------------------------------------------------

    private val _eventShowLoading: MutableLiveData<Boolean?> by lazy {
        MutableLiveData<Boolean?>()
    }

    val eventShowLoading: LiveData<Boolean?>
        get() = _eventShowLoading

    // ----------------------------------------------------------------

    fun getUsers() = viewModelScope.launch {
        _eventShowLoading.value = true

        _shopItems.value = shopListUseCase.getShopData()

        _eventShowLoading.value = false
    }

    fun clearUserObservables() {
        _shopItems.value = null
    }
}