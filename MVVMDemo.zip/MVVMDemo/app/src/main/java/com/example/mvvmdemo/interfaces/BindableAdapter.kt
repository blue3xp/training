

package com.example.mvvmdemo.interfaces

interface BindableAdapter<T> {
    fun setItems(data: T?)
}
