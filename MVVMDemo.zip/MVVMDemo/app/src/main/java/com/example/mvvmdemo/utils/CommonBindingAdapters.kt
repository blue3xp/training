

package com.example.mvvmdemo.utils

import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.ImageView
import android.widget.TextView
import androidx.databinding.BindingAdapter
import androidx.lifecycle.LiveData
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.mvvmdemo.R
import com.example.mvvmdemo.interfaces.BindableAdapter
import java.text.SimpleDateFormat
import java.util.*

// ----------------------------------------------------------------
// RecyclerView
// ----------------------------------------------------------------

/**
 * Set data to recyclerView adapter.
 *
 * Help: https://android.jlelse.eu/how-to-bind-a-list-of-items-to-a-recyclerview-with-android-data-binding-1bd08b4796b4
 */
@Suppress("UNCHECKED_CAST")
@BindingAdapter("items")
fun <T> RecyclerView.items(items: LiveData<T>?) {
    items?.apply {
        if (adapter is BindableAdapter<*>) {
            (adapter as BindableAdapter<T>).setItems(items.value)
        }
    }
}

// ----------------------------------------------------------------

/**
 * Set data to recyclerView adapter.
 *
 * @param items The item List<>.
 */
@Suppress("UNCHECKED_CAST")
@BindingAdapter("items")
fun <T> RecyclerView.items(items: T?) {
    items?.apply {
        if (adapter is BindableAdapter<*>) {
            (adapter as BindableAdapter<T>).setItems(items)
        }
    }
}



// ----------------------------------------------------------------
// ImageView
// ----------------------------------------------------------------

/**
 * Load image from url.
 */
@BindingAdapter("srcUrlProfile")
fun ImageView.setProfileImageFromUrl(url: String) {
    Glide.with(context)
        .load(url)
        .fitCenter()
        .placeholder(R.drawable.ic_add_24dp)
        .fallback(R.drawable.ic_add_24dp)
        .error(R.drawable.ic_add_24dp)
        .into(this)
}

@BindingAdapter("srcUrl")
fun ImageView.setImageFromUrl(url: String) {
    Glide.with(context)
        .load(url)
        .into(this)
}

// ----------------------------------------------------------------
// View
// ----------------------------------------------------------------

/**
 * Update view visibility.
 */
@BindingAdapter("visibility")
fun View.setVisibility(visible: Boolean?) {
    visible?.apply {
        if (this) {
            this@setVisibility.visibility = View.VISIBLE
        } else {
            this@setVisibility.visibility = View.GONE
        }
    }
}

// ----------------------------------------------------------------
// TextView
// ----------------------------------------------------------------

/**
 * Set time.
 */
@BindingAdapter("time")
fun TextView.setTimeFromDate(date: Date?) {
    text = if (date != null) {
        val simpleDateFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH)
        try {
            simpleDateFormat.format(date)
        } catch (e: Exception) {
            e.printStackTrace()
            "Error!"
        }
    } else {
        "null"
    }
}

// ----------------------------------------------------------------

@BindingAdapter("datetime")
fun TextView.setDateTimeFromDate(date: Date?) {
    text = if (date != null) {
        val simpleDateFormat = SimpleDateFormat("d MMM yyyy hh:mm a", Locale.ENGLISH)
        try {
            simpleDateFormat.format(date)
        } catch (e: Exception) {
            e.printStackTrace()
            "Error!"
        }
    } else {
        "null"
    }
}

