

package com.example.mvvmdemo.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.mvvmdemo.databinding.ShopItemBinding
import com.example.mvvmdemo.interfaces.BindableAdapter
import com.example.mvvmdemo.interfaces.OnObjectListInteractionListener
import com.example.mvvmdemo.models.shop.ShopItem


class ShopListAdapter(
    val listener: OnObjectListInteractionListener<ShopItem>
) :
    ListAdapter<ShopItem, ShopListAdapter.ListViewHolder>(DIFF_CALLBACK),
    BindableAdapter<List<ShopItem>> {

    companion object {

        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<ShopItem>() {
            override fun areItemsTheSame(
                oldItem: ShopItem,
                newItem: ShopItem
            ): Boolean {
                return oldItem.id == newItem.id
            }

            override fun areContentsTheSame(
                oldItem: ShopItem,
                newItem: ShopItem
            ): Boolean {
                return oldItem == newItem
            }
        }
    }

    override fun setItems(data: List<ShopItem>?) {
        data?.apply {
            submitList(this) {
                checkEmptiness()
            }
        }
    }

    private fun checkEmptiness() {
        if (itemCount > 0) {
            listener.hideEmptyView()
        } else {
            listener.showEmptyView()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        return ListViewHolder.from(parent, listener)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item)
    }

    class ListViewHolder private constructor(
        private val binding: ShopItemBinding,
        private val listener: OnObjectListInteractionListener<ShopItem>
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ShopItem) {
            binding.shopItem = item
            binding.executePendingBindings()
//            binding.root.setOnClickListener {
//                listener.onClick(bindingAdapterPosition, item)
//            }
//            binding.root.setOnLongClickListener {
//                listener.onLongClick(bindingAdapterPosition, item)
//
//                true
//            }
        }

        companion object {
            fun from(
                parent: ViewGroup,
                listener: OnObjectListInteractionListener<ShopItem>
            ): ListViewHolder {
                val layoutInflater = LayoutInflater.from(parent.context)
                val binding = ShopItemBinding.inflate(layoutInflater, parent, false)
                return ListViewHolder(binding, listener)
            }
        }
    }
}
