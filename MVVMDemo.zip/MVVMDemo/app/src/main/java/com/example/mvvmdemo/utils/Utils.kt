

package com.example.mvvmdemo.utils

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.media.RingtoneManager
import android.os.Build
import android.util.Patterns
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

object Utils {

    // --------------------------------
    // Notifications
    // --------------------------------
    private var notificationId = 1

    /**
     * Get device screen width in pixel.
     */
    fun getScreenWidth(): Int {
        return Resources.getSystem().displayMetrics.widthPixels
    }

    /**
     * Get device screen height in pixel.
     */
    fun getScreenHeight(): Int {
        return Resources.getSystem().displayMetrics.heightPixels
    }

    /**
     * Check if given text is valid email address.
     */
    fun isValidEmail(target: CharSequence?): Boolean {
        return if (target == null) {
            false
        } else {
            Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }
    }


    /**
     * A default try-catch block to handle general crashes.
     */
    inline fun ignoreCrash(
        couldBeCrash: () -> Unit
    ) {
        try {
            couldBeCrash()
        } catch (e: Exception) {
            /* no-op */
        }
    }
}
