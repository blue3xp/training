package com.example.mvvmdemo.models.shop

data class ShopItem (
    var description: String,
    var image: String?,
    var price: String,
    var id:Int? = 0
)